package study;

public class B extends A {
	/*void m(int a, String b) {
		
	}*/
	
	/*void arraySort(int[] arr) {
		int a;
		int min = 0;
		int tmp;
	}
	public static void main(String[] args) {
		
	int[] arr = new int[10];	
	int a = 13;
	int b = 5;
	int c = 100;
	
	if((a>b)&&(a>c)) {System.out.println("a-max");}
	else if(b<c) {System.out.println("c-max");}
	else System.out.println("b-max");
	}
}*/
	
	public static void main(String[] args) {
		
	}
	
}