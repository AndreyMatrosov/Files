package study;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Task1Test {
	
	public Task1 task1 = new Task1();

	@Test
	void testSortArray() {
		fail("Not yet implemented");
	}
	
	@Test
    public void testGetSum() throws Exception {
        assertEquals(3, task1.getSum(12));
    }
	
	/*@Test
	void testMain() {
		fail("Not yet implemented");
	}*/

}
