package study;

public class Task1 {
	
	int sum;
	
	int getSum(int var) {
		while(var != 0) {
			sum += var%10;
			var /= 10;
		}
				
		return sum;
	}
	
	void sortArr(int[] ar) {
		int tmp;
		
		for(int i = 0; i <= ar.length-1; i++) {
			//System.out.print(ar[i] + " " +ar[i+1] + "\n");
			if(getSum(ar[i]) > getSum(ar[i+1])) {
				tmp = ar[i+1];
				ar[i+1] = ar[i];
				ar[i] = tmp;
			}
			System.out.print(ar[i] + " ");
		}
	}  
	
	public static void main(String[] args) {
		
		Task1 obj = new Task1();
		int[] arr = {20, 15, 30, 10 , 12};
		obj.sortArr(arr);
		/*for(int i = 0; i < arr.length; i++) {
			//System.out.print(obj.getSum(obj.arr[i]) + " ");
			//obj.sum = 0 ;
			
		}*/
		
		
	}
	
}