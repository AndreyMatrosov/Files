package study;

import java.util.*;

public class A {
	void m(int a, String b) {
		
	}
	
	public static void main(String[] args) {
		
		String s = "Once upon a time a Wolf was lapping at a spring"
				+ " on a hillside, when, looking up, what should he "
				+ "see but a Lamb just beginning to drink a little "
				+ "lower down.\r\n";
		
		String sep = " ,";
		
		StringTokenizer sT = new StringTokenizer(s, sep);
		
		while(sT.hasMoreElements()) {
			for(char a = 97; a <= 122; a++) {
				if( (sT.nextToken().charAt(1)) == (char) a ) {
					System.out.print((char) a + sT.nextToken() + " ");
				}
			}
			//System.out.println(sT.nextToken() + " ");
		}
		
		/*Map<Integer, Integer> m = new HashMap<Integer, Integer>();
		m.put(1, 2);
		m.put(2, 2);
		Set keys = m.keySet();
		Set<Map.Entry<Integer, Integer>> s = m.entrySet();
		for(Map.Entry<Integer, Integer> m1: s) {
			System.out.print(m1.getKey() + " ");
			System.out.print(m1.getValue() + " ");
		}*/
		/*for (Integer key: keys) { 
		//�������� � ������ 
		}*/ 
	}

}
