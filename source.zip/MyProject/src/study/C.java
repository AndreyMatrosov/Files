package study;

public class C {
	public static void main(String[] args) {
		int sum_positive = 0;
		
		int[] arr = {-6, 1, 3, -2, -4, 5, 10, 2, -1};
		int tmp = arr[0];
		int tmp_max = arr[0];
		int tmp_min = arr[0];
		
		for (int i =0; i < arr.length ; i++) {
			
			if(arr[i] > tmp) {
				tmp_max = arr[i];
			}
			
			if(arr[i] < tmp) {
				tmp_min = arr[i];
			}
			System.out.print(tmp_max + " ");
			//System.out.print(tmp_min + " ");
			
		}
		
		//System.out.println(tmp);
		//System.out.println(tmp_max);
		//System.out.println(tmp_min);
		
		for (int x: arr) {
			if(x>0) {
				sum_positive += x;
			}
		}
		
		
		
		//System.out.println(sum_positive);
		
	}
}
